package cn.dq.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import cn.dq.dao.HbActivityMapper;
import cn.dq.dao.KdUserMapper;
import cn.dq.entity.HbActivity;
import cn.dq.entity.KdUser;

@Service("testService")
@Transactional
public class TestServiceImpl implements TestService{
	@Autowired
	private HbActivityMapper activityMapper;
	@Autowired
	private KdUserMapper userMapper;
	
	public Object test(Integer userId){
		System.out.println(userId);
		KdUser selectByPrimaryKey = userMapper.getUser(userId);
		return selectByPrimaryKey;
	}
	public int insert(HbActivity activity) {
		int i =activityMapper.insert(activity);
		System.out.println(i);
		throw new RuntimeException();
	}
	
	public String index(String id){
		return id;
	}
	

}
