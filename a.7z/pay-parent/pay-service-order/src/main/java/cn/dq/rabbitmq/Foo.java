package cn.dq.rabbitmq;

import org.springframework.beans.factory.annotation.Autowired;

import cn.dq.service.order.OrderService;

/**
 * 消费者
 *
 */
public class Foo {
	
	@Autowired
	private OrderService orderService;

	  //具体执行业务的方法
    public void listen(Object foo) {
        System.out.println("消费者： " + foo);
    } 
      
    /** 
     * 重复通知间隔时间（单位为秒） 
     * @param notifyCount 已经通知的次数 
     * @return 
     */  
    private int getSpacingInterval(int notifyCount) {  
        // TODO Auto-generated method stub  
        int spacingInterval = 0;  
        switch (notifyCount) {  
        case 1:  
            spacingInterval = 10;  
            break;  
        case 2:  
            spacingInterval = 20;  
            break;  
        case 3:  
            spacingInterval = 30;  
            break;  
        case 4:  
            spacingInterval = 60;  
            break;  
        case 5:  
            spacingInterval = 90;  
            break;  
        default:  
            break;  
        }  
        return spacingInterval;  
    }  
}