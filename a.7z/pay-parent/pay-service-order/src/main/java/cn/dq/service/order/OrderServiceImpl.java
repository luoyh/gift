package cn.dq.service.order;

import org.springframework.stereotype.Service;
@Service("orderService")
public class OrderServiceImpl implements OrderService{

	@Override
	public String order(String orderNo) {
		// TODO Auto-generated method stub
		return orderNo;
	}

}
