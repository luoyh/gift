package cn.dq.dao;

import cn.dq.entity.HbActivity;

public interface HbActivityMapper {
 

    int deleteByPrimaryKey(Integer id);

    int insert(HbActivity record);

    int insertSelective(HbActivity record);


    HbActivity selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(HbActivity record);

    int updateByPrimaryKey(HbActivity record);
}