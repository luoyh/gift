package cn.dq.dao;

import java.math.BigDecimal;

import cn.dq.entity.KdUser;

public interface KdUserMapper {

    int deleteByPrimaryKey(BigDecimal userId);

    int insert(KdUser record);

    int insertSelective(KdUser record);


    KdUser getUser(Integer userId);

    int updateByPrimaryKeySelective(KdUser record);

    int updateByPrimaryKey(KdUser record);
}