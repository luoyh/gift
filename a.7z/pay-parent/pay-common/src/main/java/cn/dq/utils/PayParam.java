package cn.dq.utils;
/**
 * 支付参数类
 * @author yangya
 *
 */
public class PayParam {
	
	private Integer portId;
	
	private Integer money;
	
	private String body;
	
	private String key;
	
}
