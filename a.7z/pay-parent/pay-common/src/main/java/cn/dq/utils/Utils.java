package cn.dq.utils;

import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.codec.digest.DigestUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;


public class Utils {
	/**
	 * 格式化時間
	 * @param format    yyyyMMddhhMMss
	 * @return
	 */
	public static String formatDate(String format){
		SimpleDateFormat sdf=new SimpleDateFormat(format);//格式化时间
		return sdf.format(new Date());
	}
	
	/**
	 * 生成代付订单号
	 * @return
	 */
	public static String generateOrderNo(){
		StringBuffer sb = new StringBuffer("KP");
		Random rnd = new Random();
		int num = 100 + rnd.nextInt(900);
		sb.append(new SimpleDateFormat("yyyyMMddhhMMssSSS").format(new Date())).append(num);
		return sb.toString();
	}
	
	
	/**
	 * 使用 Map按key进行排序
	 * @param map
	 * @return
	 */
	public static Map<String, String> sortMapByKey(Map<String, String> map) {
		if (map == null || map.isEmpty()) {
			return null;
		}
		Map<String, String> sortMap = new TreeMap<String, String>(
				new MapKeyComparator());

		sortMap.putAll(map);

		return sortMap;
	}
	/**
	 * 组织MD5加密串
	 * @param map
	 * @param key
	 * @return k1=aa&k2=bbkey
	 */
	public static String getSgin(Map<String, String> map, String key){
		StringBuilder signSB = new StringBuilder();
		for (Map.Entry<String, String> entry : map.entrySet()) {
			if(null!=entry.getValue() && !"".equals(entry.getValue())){
				signSB.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
			}
		}
		String substring = "";
		if (signSB.toString() != null && signSB.toString().length() > 0) {  
			substring = signSB.toString().substring(0, signSB.toString().length() - 1);  
	    }else{
	    	
	    }
		//signSB.append("sign=").append(key);
        System.out.println(substring);
        String sign = "";
		try {
			sign = DigestUtils.md5Hex((substring+key).getBytes("utf-8"));
			System.out.println(sign);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sign;
	}
	/**
	 * 将map组装成string
	 */
	public static String map2string(Map<String, String> map){
		StringBuffer sb = new StringBuffer();
		for(Entry<String, String> entry:map.entrySet()){
			if(entry.getValue()!=""||!entry.getValue().equals(null)){
				sb.append(entry.getKey()).append("=").append(entry.getValue()).append("&");
			}
		}
		if (sb.toString() != null && sb.toString().length() > 0) {  
	          return  sb.toString().substring(0, sb.toString().length() - 1);  
	        }
	        return null;
	}
	/**
	 * 
	 * @param params
	 * @return
	 */
	public static String MapToString(Map<String, String> params){
		StringBuffer sbParams = new StringBuffer();  
        if (params != null && params.size() > 0) {  
            for (Entry<String, String> e : params.entrySet()) {  
                sbParams.append(e.getKey());  
                sbParams.append("=");  
                sbParams.append(e.getValue());  
                sbParams.append("&");  
            }  
        }  
        if (sbParams != null && sbParams.length() > 0) {  
          return  sbParams.substring(0, sbParams.length() - 1);  
        }
        return null;
	}
	
	/**
	 * Map2xml
	 * @param parameters
	 * @return
	 */
    public static String map2xmlString(Map<String, String> parameters) {
        StringBuffer sb = new StringBuffer();
        sb.append("<xml>");
        Set es = parameters.entrySet();
        Iterator it = es.iterator();
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry)it.next();
            String k = (String)entry.getKey();
            String v = (String)entry.getValue();
            if (null != v && !"".equals(v) && !"appkey".equals(k)) {
                sb.append("<" + k + ">" + parameters.get(k) + "</" + k + ">\n");
            }
        }
        sb.append("</xml>");
        return sb.toString();
    }
    /**
     * map  2 xml
     * @param params
     * @return
     */
    public static String map2Xml(Map<String, String> params){
        StringBuilder buf = new StringBuilder();
        List<String> keys = new ArrayList<String>(params.keySet());
        Collections.sort(keys);
        buf.append("<xml>");
        for(String key : keys){
            buf.append("<").append(key).append(">");
            buf.append("<![CDATA[").append(params.get(key)).append("]]>");
            buf.append("</").append(key).append(">\n");
        }
        buf.append("</xml>");
        return buf.toString();
    }
    
    public static Map<String, String> toMap(byte[] xmlBytes,String charset) throws Exception{
        SAXReader reader = new SAXReader(false);
        InputSource source = new InputSource(new ByteArrayInputStream(xmlBytes));
        source.setEncoding(charset);
        Document doc = reader.read(source);
        Map<String, String> params = toMap(doc.getRootElement());
        return params;
    }
    
    private static Map<String, String> toMap(Element element){
        Map<String, String> rest = new HashMap<String, String>();
        List<Element> els = element.elements();
        for(Element el : els){
            rest.put(el.getName().toLowerCase(), el.getTextTrim());
        }
        return rest;
    }

}
