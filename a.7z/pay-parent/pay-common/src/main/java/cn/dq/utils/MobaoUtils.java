package cn.dq.utils;

import java.util.Map;

public class MobaoUtils {
	/**
	 * @author 作者: 杨亚
	 * @version 创建时间：2017年3月20日 上午9:21:44
	 * 类说明	将由支付请求参数构成的map转换成支付串，并对参数做合法验证
	 * 由支付请求参数构成的map
	 */
	public static String generatePayRequest(Map<String, String> paramsMap){

		// 输入数据组织成字符串
		String paramsStr = String
				.format(
						"apiName=%s&apiVersion=%s&platformID=%s&merchNo=%s&orderNo=%s&tradeDate=%s&amt=%s&merchUrl=%s&merchParam=%s&tradeSummary=%s",
						paramsMap.get("apiName"), paramsMap.get("apiVersion"),
						paramsMap.get("platformID"), paramsMap.get("merchNo"),
						paramsMap.get("orderNo"), paramsMap.get("tradeDate"),
						paramsMap.get("amt"), paramsMap.get("merchUrl"),
						paramsMap.get("merchParam"), paramsMap
								.get("tradeSummary"));

		return paramsStr;
	}
}
