package cn.dq.utils;

import java.util.Comparator;

/**
 * @author 作者 E-mail:杨亚
 * @version 创建时间：2016年12月28日 上午9:02:33
 * 类说明
 */
public class MapKeyComparator implements Comparator<String>{

	@Override
	public int compare(String str1, String str2) {
		return str1.compareTo(str2);
	}

}
