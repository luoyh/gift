package cn.dq.service.api;
/**
 * @author 作者: 杨亚
 * @version 创建时间：2017年3月20日 上午9:21:44
 * 类说明    接收通知接口
 */
public interface NotifyUrlService {
	
	public void noyifyUrl(String type,String orderNo);
	/**
	 * 代付异步通知
	 */
	public void agentNotifyUrl();
	
	public void sendMsg(String type,String orderNo);

}
