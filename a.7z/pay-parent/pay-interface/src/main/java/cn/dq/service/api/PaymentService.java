package cn.dq.service.api;

public interface PaymentService {
	
	public String payMent();

}
