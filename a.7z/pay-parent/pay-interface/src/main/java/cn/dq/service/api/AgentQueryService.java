package cn.dq.service.api;

public interface AgentQueryService {

}
