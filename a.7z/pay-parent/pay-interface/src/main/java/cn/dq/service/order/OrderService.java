package cn.dq.service.order;

public interface OrderService {
	
	public String order(String orderNo);
	

}
