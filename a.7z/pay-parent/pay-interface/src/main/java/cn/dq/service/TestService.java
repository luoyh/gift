package cn.dq.service;

import cn.dq.entity.HbActivity;

public interface TestService {

	public Object test(Integer id);
	
	public int insert(HbActivity activity);
	public String index(String id);
	
}
