package cn.dq.service.api;

public interface AgentPayService {
	public void agentPay();
}
