package cn.dq.service;

public interface NotifyService {
	
	public String notify(String id);
	
	public void testNotify(String type,String orderNo);

}
