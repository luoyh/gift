package cn.dq.service.api;


public interface ApiService {
	
	public void putMq(String orderNo,String type);

}
