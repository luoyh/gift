package cn.dq.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class KdUser implements Serializable{

	private static final long serialVersionUID = 1L;

	private BigDecimal userId;

    private BigDecimal kdUserId;

    private String userName;

    private String passWord;

    private Date registerTime;

    private Date modifierTime;

    private String userType;

    private String openId;

    private String dealPassWord;

    private String idNumber;

    private String name;

    private String authPhone;

    private String authName;

    public BigDecimal getUserId() {
        return userId;
    }

    public void setUserId(BigDecimal userId) {
        this.userId = userId;
    }

    public BigDecimal getKdUserId() {
        return kdUserId;
    }

    public void setKdUserId(BigDecimal kdUserId) {
        this.kdUserId = kdUserId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName == null ? null : userName.trim();
    }

    public String getPassWord() {
        return passWord;
    }

    public void setPassWord(String passWord) {
        this.passWord = passWord == null ? null : passWord.trim();
    }

    public Date getRegisterTime() {
        return registerTime;
    }

    public void setRegisterTime(Date registerTime) {
        this.registerTime = registerTime;
    }

    public Date getModifierTime() {
        return modifierTime;
    }

    public void setModifierTime(Date modifierTime) {
        this.modifierTime = modifierTime;
    }

    public String getUserType() {
        return userType;
    }

    public void setUserType(String userType) {
        this.userType = userType == null ? null : userType.trim();
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId == null ? null : openId.trim();
    }

    public String getDealPassWord() {
        return dealPassWord;
    }

    public void setDealPassWord(String dealPassWord) {
        this.dealPassWord = dealPassWord == null ? null : dealPassWord.trim();
    }

    public String getIdNumber() {
        return idNumber;
    }

    public void setIdNumber(String idNumber) {
        this.idNumber = idNumber == null ? null : idNumber.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getAuthPhone() {
        return authPhone;
    }

    public void setAuthPhone(String authPhone) {
        this.authPhone = authPhone == null ? null : authPhone.trim();
    }

    public String getAuthName() {
        return authName;
    }

    public void setAuthName(String authName) {
        this.authName = authName == null ? null : authName.trim();
    }
}