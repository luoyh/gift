package cn.dq.entity;

import java.io.Serializable;

public class HbActivity implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer id;

    private String activityid;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getActivityid() {
        return activityid;
    }

    public void setActivityid(String activityid) {
        this.activityid = activityid == null ? null : activityid.trim();
    }

	@Override
	public String toString() {
		return "HbActivity [id=" + id + ", activityid=" + activityid + "]";
	}
}