package cn.dq.service;

import org.springframework.stereotype.Service;

import cn.dq.nitify.Notify;

@Service("notifyService")
public class NotifyServiceImpl implements NotifyService{

	@Override
	public String notify(String id) {
		// TODO Auto-generated method stub
		return id;
	}
	
	public void testNotify(String type,String orderNo){
		Notify notify = new Notify();
		notify.setType(type);
		notify.setOrderNo(orderNo);
	}

}
