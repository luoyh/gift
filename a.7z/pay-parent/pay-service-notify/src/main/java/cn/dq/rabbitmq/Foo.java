package cn.dq.rabbitmq;


/**
 * 消费者
 *
 */
public class Foo {

    //具体执行业务的方法
    public void listen(Object foo) {
        System.out.println("消费者： " +foo);
    }
}