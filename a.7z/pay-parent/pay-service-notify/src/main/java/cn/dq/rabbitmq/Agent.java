package cn.dq.rabbitmq;

public class Agent {
	   //具体执行业务的方法
    public void listen(Object foo) {
        System.out.println("消费者agent： " +foo);
    }

}
