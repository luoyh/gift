package cn.dq.rabbitmq;

import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
public class Test {
	 private static final ObjectMapper MAPPER = new ObjectMapper();
	@Autowired
	private RabbitTemplate rabbitTemplate;
	   //具体执行业务的方法
    public void listen(String foo) {
    	//Notify parse = (Notify)JSONObject.parse(foo);
		try {
			JsonNode jsonNode = MAPPER.readTree(foo);
			
			 String type = jsonNode.get("type").asText();
			 String orderNo = jsonNode.get("orderNo").asText();
		     System.out.println("test消费者： " +type+"=="+orderNo);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
       
       // rabbitTemplate.convertAndSend("test", foo);
       /* rabbitTemplate.convertAndSend("test", (Object) foo,  
                new MessagePostProcessor() {  
  
                    @Override  
                    public Message postProcessMessage(Message message)  
                            throws AmqpException {  
                        // TODO Auto-generated method stub  
                        message.getMessageProperties().setDelay(Integer.parseInt(foo));  
                        return message;  
                    }  
                });  */
    }
    
    /**
     * 单独起一个线程往队列里面放商户异步地址未成功返回的消息，以便实现重发机制
     * @param kdNotifyRecord
     */
	private synchronized void putRabbitmq(final Map<String, Object> map){
		int notifyCount = Integer.parseInt(map.get("count").toString());
		int delay = 0;
		if(notifyCount==1){
			delay = 10;
		}else if(notifyCount==2){
			delay = 2*20;
		}else if(notifyCount==3){
			delay = 3*30;
		}else if(notifyCount==4){
			delay = 4*40;
		}else if(notifyCount==5){
			delay = 5*50;
		}else{
			delay = 6*60;
		}
			Executors.newScheduledThreadPool(1).schedule(new Runnable() {
				@Override
				public void run() {
					 try {
							String writeValueAsString = MAPPER.writeValueAsString(map);
							rabbitTemplate.convertAndSend(map.get("type").toString(),writeValueAsString );
						} catch (JsonProcessingException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
				}
			}, delay, TimeUnit.SECONDS);
		
	}
    
}
