package cn.dq.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.dq.entity.HbActivity;
import cn.dq.service.TestService;
import cn.dq.service.order.OrderService;

@Controller
public class TestController {
	@Autowired
	private TestService testService;
	@Autowired
	private OrderService orderService;
	
	@RequestMapping("/test.do")
	@ResponseBody
	public Object test(Integer id,HttpServletRequest request){
	
		Object test = testService.test(id);
		return test;
	}
	
	@RequestMapping("/index.do")
	@ResponseBody
	public Object index(String id){
	
		Object test = testService.index(id);
		return test;
	}
	
	@RequestMapping("/insert.do")
	@ResponseBody
	public Object insert(HbActivity activity){
	
		Object test = testService.insert(activity);
		return test;
	}
	
	@RequestMapping("/order.do")
	@ResponseBody
	public Object order(String orderNo){
	
		Object test = orderService.order(orderNo);
		return test;
	}
	
	@RequestMapping("/rabbit.do")
	@ResponseBody
	public Object rabbit(Integer count,String orderNo){
	
		return null;
	}

}
