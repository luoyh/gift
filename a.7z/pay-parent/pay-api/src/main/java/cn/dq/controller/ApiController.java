package cn.dq.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.dq.service.NotifyService;
import cn.dq.service.api.AgentPayService;
import cn.dq.service.api.NotifyUrlService;
import cn.dq.service.api.PaymentService;

@Controller
public class ApiController {
	@Autowired
	private NotifyService notifyService;
	@Autowired
	private NotifyUrlService notifyUrlService;
	@Autowired
	private PaymentService paymentService;
	@Autowired
	private AgentPayService agentPayService;
	
	@RequestMapping("api.do")
	@ResponseBody
	public Object api(String id){
		
		String index = notifyService.notify(id);
		return index;
	}
	
	@RequestMapping("notifyUrl.do")
	@ResponseBody
	public Object notifyUrl(String type,String orderNo){
		notifyUrlService.noyifyUrl(type, orderNo);
		return 11111;
	}
	/**
	 * 发起支付
	 * @return
	 */
	@RequestMapping("payment.do")
	@ResponseBody
	public Object payment(){
		return paymentService.payMent();
	}
	
	/**
	 * 代付发起支付
	 * @return
	 */
	@RequestMapping("/agentPay.do")
	@ResponseBody
	public Object agentPay(HttpServletRequest request,HttpServletResponse response){
		
		agentPayService.agentPay();
		
		return null;
	}
	/**
	 * 代付接收异步通知
	 * @param request
	 */
	@RequestMapping("/agentNotifyUrl.do")
	@ResponseBody
	public void agentNotifyUrl(HttpServletRequest request){
		showParams(request);
	}
	/**
	 * 测试一麻袋支付
	 * @param model
	 * @param entity
	 * @return
	 */
	@RequestMapping("topayment")
	public String topayment(Model model){
		String MD5key = ")fNAmBMY"; //MD5key值   
	    String MerNo = "1685";   //商户ID
	    model.addAttribute("MerNo", MerNo);
	    String BillNo = String.valueOf(System.currentTimeMillis()); //订单编号
	    model.addAttribute("BillNo", BillNo);
	    String Amount = "1";  //支付金额
	    model.addAttribute("Amount", Amount);
	    String ReturnURL = "";   //返回地址
	    model.addAttribute("ReturnURL", ReturnURL);
		//[必填]返回数据给商户的地址(商户自己填写):::注意请在测试前将该地址告诉我方人员;否则测试通不过
		String AdviceURL ="http://192.168.1.170/ecpss/payresult.jsp";   //[必填]支付完成后，后台接收支付结果，可用来更新数据库值
		model.addAttribute("AdviceURL", AdviceURL);
		String OrderTime = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());//交易时间
		model.addAttribute("OrderTime", OrderTime);
		//送货信息(方便维护，请尽量收集！如果没有以下信息提供，请传空值:'')
		 //因为关系到风险问题和以后商户升级的需要，如果有相应或相似的内容的一定要收集，实在没有的才赋空值,谢谢。
		String  defaultBankNumber="ICBC";		//[选填]银行代码
		model.addAttribute("defaultBankNumber", defaultBankNumber);
		//账单地址选择传递
		String products="products info";// '------------------物品信息
		model.addAttribute("products", products);
		String md5src = "MerNo="+MerNo +"&"+ "BillNo="+BillNo +"&"+ "Amount="+Amount +"&"+"OrderTime="+OrderTime+"&"+ "ReturnURL="+ReturnURL +"&"+"AdviceURL="+AdviceURL+"&"+MD5key ;  //加密字符串    
	    HCMD5 md5 = new HCMD5();
	    String SignInfo = md5.getMD5ofStr(md5src);//MD5检验结果//MD5加密后的字符串
	    model.addAttribute("SignInfo", SignInfo);
	    String Remark = "备注";
	    model.addAttribute("Remark", Remark);
	    String payType = "";
	    model.addAttribute("payType", payType);
	    String url = "https://gwapi.yemadai.com/pay/sslpayment";
	    model.addAttribute("url", url);
		return "/paysubmit";
	}
	
	
	private void showParams(HttpServletRequest request) {  
        Map<String,String> map = new HashMap<String,String>();  
        Enumeration paramNames = request.getParameterNames();  
        while (paramNames.hasMoreElements()) {  
            String paramName = (String) paramNames.nextElement();  
  
            String[] paramValues = request.getParameterValues(paramName);  
            if (paramValues.length == 1) {  
                String paramValue = paramValues[0];  
                if (paramValue.length() != 0) {  
                    map.put(paramName, paramValue);  
                }  
            }  
        }  
  
        Set<Map.Entry<String, String>> set = map.entrySet();  
        System.out.println("------------------------------");  
        for (Map.Entry entry : set) {  
            System.out.println(entry.getKey() + ":" + entry.getValue());  
        }  
        System.out.println("------------------------------");  
    }

}
