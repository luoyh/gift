package cn.dq.service.api;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import cn.dq.utils.HttpClientUtil;
import cn.dq.utils.Utils;
/**
 * @author 作者: 杨亚
 * @version 创建时间：2017年3月20日 上午9:21:44
 * 类说明    代付发起支付
 */
@Service("agentPayService")
public class AgentPayServiceImpl implements AgentPayService{

	@Value("${AGENT_NOTIFYURL}")
	private String AGENT_NOTIFYURL;
	
	@Override
	public void agentPay() {
		// TODO Auto-generated method stub
		System.out.println(AGENT_NOTIFYURL);
	/*	cxAgentOne();
		mobaoAgent();
		heepayAgent();*/
		//zwxAgent();
		cxAgentOne();
		mobaoAgent();
		
	}
	
	/**   创新单笔代付========================================================================  */
	
	private String cxAgentOne(){
		Map<String, String> map = new HashMap<String, String>();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
		String time = df.format(new Date());
		String url = "http://api.shijihuitong.com/cxpayApi/agentPay";//此为测试地址，商户应使用文档中的正式地址
		String key = "c0449b0d72c44389b0a14569f1671e99";//密钥需要商户替换为自己的密钥


		String service = "payForAnotherOne";	    //必填	接口名称
		String merchantNo = "CX0000938";	//必填	商户编号如1001
		String orderNo = "Order"+time;	//必填	商户订单号
		String version = "V1.0";	//必填	网关版本
		String accountProp = "1";	//必填	对公对私 1=私人；2=公司
		
		String accountNo = Base64.encodeBase64String("6217003760105189707".getBytes());	//必填	银行卡或存折号码；内容用base64加密,在生成 sign之前
		String accountName = Base64.encodeBase64String("yangya".getBytes());	//必填	银行卡或存折上的所有人姓名。内容用base64加密,在生成 sign之前
		String bankGenneralName = "中国人民银行";	//必填	银行名称：如：中国人民银行
		String bankName = "金牛区支行";	//必填	开户行详细名称，也叫网点，如：金牛区支行
		String bankCode = "ICBC";	//必填	对方开户行行号，对方账户对应的支行行号：如：ICBC
		String currency = "CNY";	//必填	人民币：CNY；港元:HKD；美元USD；目前只支持人民币CNY
		String bankProvcince = "测试";	//必填	带“省”、“自治区”，如广东省，广西省，内蒙古自治区等
		String bankCity = "成都市";	//必填	带市，如上海市、成都市等
		String orderAmount = "100";	//必填	整数，单位分
		String tel = "18290461556";	//可空	不带括号，减号
		String cause = "打款原因";	//可空	打款原因
		String orderTime = df.format(new Date());	//必填	商户订单提交时间，格式：YYYYMMDD24HHMMSS
		String notifyUrl = AGENT_NOTIFYURL;	//可空	异步通知请求地址
		
		
		map.put("service", service);
		map.put("merchantNo", merchantNo);
		map.put("orderNo", orderNo);
		map.put("version", version);
		map.put("accountProp", accountProp);
		map.put("accountNo", accountNo);
		map.put("accountName", accountName);
		map.put("bankGenneralName", bankGenneralName);
		map.put("bankName", bankName);
		map.put("bankCode",bankCode );
		map.put("currency",currency );
		map.put("bankProvcince", bankProvcince);
		map.put("orderTime",orderTime );
		map.put("bankCity", bankCity);
		map.put("orderAmount", orderAmount);
		map.put("notifyUrl", notifyUrl);
		Map<String, String> sortMap = Utils.sortMapByKey(map);	//按Key进行排序
		//测试代码  TODO
		for (Map.Entry<String, String> entry : sortMap.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
		String map2string = Utils.map2string(sortMap);
		String sign = "";
		try {
			sign = DigestUtils.md5Hex((map2string+key).getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/*map.put("cause",cause );
		map.put("tel", tel);
		map.put("notifyUrl", notifyUrl);*/
		map.put("sign", sign);
		String result = HttpClientUtil.doPost(url, map);
		System.out.println(result);
		//Map<String, String> resultMap = paseString2(result);
		return result;
	}
	
	/**   汇付宝========================================================================  */
	private String heepayAgent(){
		Map<String, String> map = new HashMap<String, String>();
		String url = "https://Pay.heepay.com/API/PayTransit/PayWithSmallAll.aspx";//此为测试地址，商户应使用文档中的正式地址
		String key = "B323E1DCF26C419598CCF8CB";//密钥需要商户替换为自己的密钥
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
		String time = df.format(new Date());
		
		String version = "2";	    //必填	当前接口版本号 2
		String agent_id = "2065443";	//必填	商户编号如1001
		
		String batch_no = "Order"+time;	//必填	批量付款定单号（要保证唯一）。长度最长50字符	11<批量付款定单号<50
		String batch_amt = "1.02";	//必填	付款总金额不可为空，单位：元，小数点后保留两位。12.37
		String batch_num = "1";	//必填	该次付款总笔数，付给多少人的数目，“单笔数据集”里面的数据总笔数
		String detail_data = "qq111172^3^0^6228480018564699379^李雪^1.02^供应商结算款^北京^北京市^中国农业银行股份有限公司北京海淀大街支行";	//必填	批付到银行帐户格式:“商户流水号^银行编号^对公对私^收款人帐号^收款人姓名^付款金额^付款理由^省份^城市^收款支行名称”来组织数据，每条整数据间用“|”符号分隔商户流水号长度最长20字符银行编号：参照枚举类型1,对公对私：参照枚举类型2
		String notify_url = "AGENT_NOTIFYURL";	//必填	支付后返回的商户处理页面，URL参数是以http://或https://开头的完整URL地址(后台处理)
		String ext_param1 = "beizhu";	//必填	商户自定义原样返回,长度最长50字符
		//map.put("time", time);
		map.put("agent_id",agent_id );
		map.put("version", version);
		//map.put("key", key);
		map.put("batch_no", batch_no);
		map.put("batch_amt", batch_amt);
		map.put("batch_num",batch_num );
		
		map.put("detail_data",detail_data );
		map.put("notify_url", notify_url);
		map.put("ext_param1",ext_param1 );
		map.put("key", key);
		Map<String, String> sortMap = Utils.sortMapByKey(map);
		String map2string = Utils.map2string(sortMap);
		String sign = "";
		try {
			sign = DigestUtils.md5Hex((map2string.toLowerCase()).getBytes("utf-8")).toLowerCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		map.remove("key");
		map.put("sign", sign);
		
		String result = HttpClientUtil.doPost(url, map);
		System.out.println(result);
		return result;
	}
	
	/**   墨宝代付========================================================================  */
	private String mobaoAgent(){
		Map<String, String> map = new HashMap<String, String>();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");//设置日期格式
		String apiName = "SINGLE_ENTRUST_SETT";	    //必填	接口名字
		String apiVersion = "1.0.0.0";	//必填	接口版本
		String platformID = "210001430017532";	//必填	平台ID
		String merchNo = "210001430017532";	//必填	商户账号
		String tradeDate = df.format(new Date());//交易日期 必输YYYYMMDD年月日
		String orderNo =  new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());	//必填	商户订单号
		String merchUrl = AGENT_NOTIFYURL;	//必填	委托结算结果通知地址 接收通知的URL地址，如：http://www.merchant.com/handler.jsp
		String merchParam = "yangya";	//商户参数    选输  需要摩宝在委托结算结果通知中转发的商户参数，此参数可以使用商户自己的加密方式或者编码方式对值进行处理,但是此参数最后必须是经过URLEncode编码，这样Mo宝支付系统才能被正确解析
		String bankAccNo = "6228480018564699379";	//必填	商户自定义原样返回,长度最长50字符
		String bankAccName = "李雪";//银行卡户名   必输 收款人银行卡卡号
		String bankCode = "ICBC";//银行卡银行代码 必输收款人银行代码，如CMB、ICBC详见：3.银行代码表
		String bankName = "工商银行成都高新支行";//银行卡开户行名称  必输必须包含完整的开户支行信息，如：工商银行成都高新支行
		String amt = "1.00";//结算金额  必输保留2位小数，单位：元例如：12.02、12.00、12
		String tradeSummary = "";
		try {
			tradeSummary = URLEncoder.encode("yangya","utf-8");
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}//选输对交易的简单说明
		String signMsg = "";//交易摘要	 必输，商户对交易数据的签名，签名通过API生成。
		String key = "e5559f05188766d7f99128eedbcf515b";
		String url = "https://trade.mobaopay.com/cgi-bin/netpayment/pay_gate.cgi";
		
		map.put("apiName", apiName);
		map.put("apiVersion",apiVersion );
		map.put("platformID",platformID );
		map.put("merchNo", merchNo);
		map.put("orderNo", orderNo);
		map.put("tradeDate", tradeDate);
		map.put("merchUrl",merchUrl );
		map.put("merchParam",merchParam );
		map.put("bankAccNo", bankAccNo);
		map.put("bankAccName",bankAccName );
		map.put("bankCode",bankCode );
		map.put("bankName",bankName );
		map.put("amt",amt );
		map.put("tradeSummary",tradeSummary );
		String paramsStr = String.format(
				"apiName=%s&apiVersion=%s&platformID=%s&merchNo=%s&orderNo=%s&tradeDate=%s&merchUrl=%s&merchParam=%s&bankAccNo=%s&bankAccName=%s&bankCode=%s&bankName=%s&Amt=%s&tradeSummary=%s",
				map.get("apiName"), map.get("apiVersion"),
				map.get("platformID"), map.get("merchNo"),
				map.get("orderNo"), map.get("tradeDate"),
				map.get("merchUrl"),
				map.get("merchParam"),map.get("bankAccNo"),
				map.get("bankAccName"),map.get("bankCode"),
				map.get("bankName"),map.get("amt"),
				map.get("tradeSummary"));
	
		System.out.println("paramsStr====="+paramsStr);
		try {
			signMsg = DigestUtils.md5Hex((paramsStr+key).getBytes("utf-8")).toLowerCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	// 签名数据
		//StringBuffer sb = new StringBuffer().append(msgMap.get("paramsStr")).append("&signMsg=").append(signMsg);
		map.put("signMsg",signMsg );
		StringBuffer sb = new StringBuffer().append(paramsStr).append("&signMsg=").append(signMsg);
		String doPost = HttpClientUtil.doPostJson(url, sb.toString());
		/*String doPost = HttpUtil.doPost(map.get("url"), "utf-8", sb.toString());
		Map<String, String> resultMap = parsString(doPost);*/
		System.out.println(doPost);
		return doPost;
	}
	
	
	/**   紫微星========================================================================  */
	public String zwxAgent(){
		Map<String, String> map = new HashMap<String, String>();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMddHHmmss");//设置日期格式
		String time = df.format(new Date());
		String url = "https://api.zwxpay.com/pay/agentpay/single";//此为测试地址，商户应使用文档中的正式地址
		String key = "http://211.10";
		
		String mch_id = "2";	    //必填	商户号 
		String nonce_str = "1023";	//必填	随机字符串，丌长于32位 
		String out_trade_no  = "Order"+time;//"A810E85881C74460BD6E0397";//商户订单号
		String total_fee  = "1";	//必填	订单总金额，单位为分，只能为整数 单笔最大丌超过5万元 单笔最小丌低于1元
		String body  = "body";	//必填	代付简要描述 
		String pay_type  = "0";	//必填	0：对私，1：对公
		String pay_name  = "李雪";	//必填	收款银行账户姓名 
		String pay_card_no = "6228480018564699379";	//必填	收款银行账户账号 
		String bank_union_no = "";	//否 	对公账户必须有联行号，对私账户丌需要 收款银行的联行号，可在网上查询： http://www.lianhanghao.com 
		String op_user_id = "beizhu";	//否 	操作员帐号
		String sign  = "";	//是 	签名，详见签名生成算法 
		
		map.put("mch_id", mch_id);
		map.put("nonce_str",nonce_str );
		map.put("out_trade_no",out_trade_no );
		map.put("total_fee", total_fee);
		map.put("body", body);
		map.put("pay_type", pay_type);
		map.put("pay_name",pay_name );
		map.put("pay_card_no",pay_card_no );
		map.put("bank_union_no", bank_union_no);
		map.put("op_user_id",op_user_id );
		Map<String, String> sortMap = Utils.sortMapByKey(map);
		String map2string = Utils.map2string(sortMap);
		try {
			sign = DigestUtils.md5Hex(((map2string+"&key="+key).toLowerCase()).getBytes("utf-8")).toLowerCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		map.put("sign", sign);
		String result = HttpClientUtil.doPost(url, map);
		System.out.println(result);
		//Map<String, String> resultMap = parsString(result);
		return result;
	}
	

}
