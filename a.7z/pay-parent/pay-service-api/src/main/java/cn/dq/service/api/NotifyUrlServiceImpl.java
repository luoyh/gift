package cn.dq.service.api;

import java.util.HashMap;
import java.util.Map;

import org.springframework.amqp.AmqpException;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.amqp.AmqpException;  
import org.springframework.amqp.core.AmqpTemplate;  
import org.springframework.amqp.core.Message;  
import org.springframework.amqp.core.MessagePostProcessor; 

import cn.dq.nitify.Notify;
/**
 * @author 作者: 杨亚
 * @version 创建时间：2017年3月20日 上午9:21:44
 * 类说明	接收上游通知
 */
@Service("notifyUrlService")
public class NotifyUrlServiceImpl implements NotifyUrlService{
	private static final ObjectMapper MAPPER = new ObjectMapper();
	
	@Value("${AGENT_NOTIFYURL}")
	private String AGENT_NOTIFYURL;
	@Autowired
	private RabbitTemplate rabbitTemplate;
	@Override
	public void noyifyUrl(String type,String orderNo) {
		/*Notify notify = new Notify();
		notify.setType(type);
		notify.setOrderNo(orderNo);*/
		System.out.println(AGENT_NOTIFYURL);
		sendMsg(type,orderNo);
	}
	
	public void sendMsg(String type,final String orderNo){
		//JSONObject fromObject = JSONObject.fromObject(notify);
		 Map<String, Object> msg = new HashMap<String, Object>();
        msg.put("orderNo", orderNo);
        msg.put("type", type);
        try {
			String writeValueAsString = MAPPER.writeValueAsString(msg);
			//rabbitTemplate.convertAndSend(type,writeValueAsString );
			rabbitTemplate.convertAndSend("test", (Object)writeValueAsString,  
	                new MessagePostProcessor() {  
	  
	                    @Override  
	                    public Message postProcessMessage(Message message)  
	                            throws AmqpException {  
	                        // TODO Auto-generated method stub  
	                        message.getMessageProperties().setDelay(Integer.parseInt(orderNo));  
	                        return message;  
	                    }  
	                });
			
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	};
	
	public void sendMsg1(Notify notify){
		//JSONObject fromObject = JSONObject.fromObject(notify);
		Object json = JSONObject.toJSON(notify);
		rabbitTemplate.convertAndSend(notify.getType(),json);
		
	}
	/**
	 * 代付异步通知
	 */
	@Override
	public void agentNotifyUrl() {
		
	};
}
