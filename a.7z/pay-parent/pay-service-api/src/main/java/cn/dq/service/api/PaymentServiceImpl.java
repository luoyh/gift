package cn.dq.service.api;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedMap;
import java.util.TreeMap;

import org.apache.commons.codec.digest.DigestUtils;
import org.bouncycastle.util.encoders.Base64;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;

import cn.dq.utils.HttpClientUtil;
import cn.dq.utils.MobaoHttpUtils;
import cn.dq.utils.MobaoUtils;
import cn.dq.utils.Utils;
import cn.dq.utils.WftUtils;
/**
 * @author 作者: 杨亚
 * @version 创建时间：2017年3月20日 上午9:21:44
 * 类说明	发起支付
 */
@Service("paymentService")
public class PaymentServiceImpl implements PaymentService{
	
	public String payMent(){
		
		//mobaoPay();
		
		return ecpssPay();
	}
	
	
	
	/**   威富通支付宝========================================================================  */
	private String wftAliPay(){
		Map<String,String> result = new HashMap<String,String>();
		String url = "https://pay.swiftpass.cn/pay/gateway";
		SortedMap<String, String> param = new TreeMap<String, String>();
		param.put("service", "pay.alipay.native");//接口类型
		param.put("mch_id", "7551000001");//商户号
		String out_trade_no = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		param.put("out_trade_no", out_trade_no);//商户订单号
		param.put("body", "body");//商品描述
		//param.put("attach", "附加信息");//附加信息
		int total_fee = 100;
		param.put("total_fee", total_fee+"");//总金额
		param.put("mch_create_ip", "192.168.1.170");//终端ip
		param.put("notify_url", "http://test");//通知地址
		param.put("nonce_str", String.valueOf(new Date().getTime()));//随机字符串
		Map<String,String> params =WftUtils.paraFilter(param);
        StringBuilder buf = new StringBuilder((params.size() +1) * 10);
        WftUtils.buildPayParams(buf,params,false);
        String preStr = buf.toString();
        String sign = WftUtils.sign(preStr, "&key=9d101c97133837e13dde2d32a5054abb", "utf-8");
        param.put("sign", sign);
        result = WftUtils.wftPost(url, param);
        System.out.println(WftUtils.toXml(result));
		return result.get("code_img_url");
        
        
	}
	

	
	/**   Mo宝支付========================================================================  */
	private void mobaoPay(){
		String orderNo = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
		String tradeDate = new SimpleDateFormat("yyyyMMdd").format(new Date());
		Double amt = 0.01;
		String merchParam = "abcd";
		String tradeSummary = "支付测试";
		String bankCode = "MOBAOPAY";
		String key = "b87ade8eb2321835daa0330d581c7123";
		String epayUrl = "https://trade.mobaopay.com/cgi-bin/netpayment/pay_gate.cgi";
		String charset = "UTF-8";
		String choosePayType ="4";//选择支付方式 1.网银2.一键支付3非银行支付4 支付宝扫描5微信扫码
		SortedMap<String, String> params = new TreeMap<String, String>();
		//Map<String, String> params = new HashMap<String, String>();
		params.put("apiName", "WEB_PAY_B2C");//接口名字WAP方式：“WAP_PAY_B2C”（手机支付）,WEB方式：“WEB_PAY_B2C”（pc浏览器）
		params.put("apiVersion", "1.0.0.0");//接口版本
		params.put("platformID", "210001510010949");//商户(合作伙伴)Id
		params.put("merchNo", "210001510010949");//商户账号
		params.put("orderNo", orderNo);//商户订单号
		params.put("tradeDate", tradeDate);//交易日期
		params.put("amt", amt.toString());//订单金额
		params.put("merchUrl", "http://192.168.1.170:8080/dfgdg/callBack.jsp");//支付结果通知地址
		params.put("merchParam", merchParam);//商户参数
		params.put("tradeSummary", tradeSummary);
		params.put("bankCode", bankCode);//银行代码
		params.put("choosePayType",choosePayType);//选择支付方式 1.网银2.一键支付3非银行支付4 支付宝扫描5微信扫码
		//map拼接成string
		String generatePayRequest = MobaoUtils.generatePayRequest(params);
		try {
			//生成加密串
			String sign = DigestUtils.md5Hex((generatePayRequest+key).getBytes("utf-8")).toUpperCase();
			params.put("signMsg", sign);
			String doPost = HttpClientUtil.doPost(epayUrl, params);
			Document doc = Jsoup.parse(doPost);
			Elements elementsByTag = doc.getElementsByTag("input");
			Map<String, String> jsoupMap = new HashMap<String, String>();
			for(Element e:elementsByTag){
				String name = e.attr("name");
				String value = e.attr("value");
				jsoupMap.put(name, value);
			}
			System.out.println(Utils.MapToString(jsoupMap));
			String url="https://trade.mobaopay.com/standard/payment/cashier.cgi";
			String jsouup = MobaoHttpUtils.doPost(url, jsoupMap, charset,epayUrl);
			Document doc2 = Jsoup.parse(jsouup);
			Element form = doc2.getElementsByTag("form").first();
			Elements inputs = form.getElementsByTag("input");
			Map<String, String> jsoupMapTwo = new HashMap<String, String>();
			for(Element input : inputs){
				String name = input.attr("name");
				String value = input.attr("value");
				jsoupMapTwo.put(name, value);
			}
			if("5"==choosePayType || "5".equals(choosePayType)){
				jsoupMapTwo.put("bankCode", "WXSP");
				jsoupMapTwo.put("payType", "16");
				jsoupMapTwo.put("__long", "ZElJ4R73oucRitV1");
			}else{
				jsoupMapTwo.put("bankCode", "ALSP");
				jsoupMapTwo.put("payType", "15");
				jsoupMapTwo.put("__long", "ZElJ4R73oucRitV2");
			}
			jsoupMapTwo.put("m", "getCodeUrl");
			String jsouup2 = MobaoHttpUtils.doPost("https://trade.mobaopay.com/standard/gateway/manager.cgi", jsoupMapTwo, charset,url);
			JSONObject jsonObj = JSONObject.parseObject(jsouup2);
			String codeUrl = jsonObj.getString("codeUrl");
			byte[] decode = Base64.decode(codeUrl);
			System.out.println(new String(codeUrl));
			System.out.println(new String(decode));
			
			
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	/**   汇潮支付========================================================================  */
	private String ecpssPay(){
		Map<String, String> map = new HashMap<String, String>();
		String MD5key = ")fNAmBMY"; //MD5key值
	    String MerNo = "1685";   //商户ID
	    map.put("MerNo", MerNo);
	    String BillNo = String.valueOf(System.currentTimeMillis()); //订单编号
	    map.put("BillNo", BillNo);
	    String Amount = "0.01";  //支付金额
	    map.put("Amount", Amount);
	    String ReturnURL = "http://192.168.1.170/ecpss/payresult.jsp";   //返回地址
	    map.put("ReturnURL", ReturnURL);
		//[必填]返回数据给商户的地址(商户自己填写):::注意请在测试前将该地址告诉我方人员;否则测试通不过
		String AdviceURL ="http://192.168.1.170/ecpss/payresult.jsp";   //[必填]支付完成后，后台接收支付结果，可用来更新数据库值
		map.put("AdviceURL", AdviceURL);
		String OrderTime = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());//交易时间
		map.put("OrderTime", OrderTime);
		//送货信息(方便维护，请尽量收集！如果没有以下信息提供，请传空值:'')
		 //因为关系到风险问题和以后商户升级的需要，如果有相应或相似的内容的一定要收集，实在没有的才赋空值,谢谢。
		String  defaultBankNumber="ICBC";		//[选填]银行代码
		map.put("defaultBankNumber", defaultBankNumber);
		//账单地址选择传递
		String products="products info";// '------------------物品信息
		map.put("products", products);
		String md5src = "MerNo="+MerNo +"&"+ "BillNo="+BillNo +"&"+ "Amount="+Amount +"&"+"OrderTime="+OrderTime+"&"+ "ReturnURL="+ReturnURL +"&"+"AdviceURL="+AdviceURL+"&"+MD5key ;  //加密字符串    
		String SignInfo = "";
		try {
			SignInfo = DigestUtils.md5Hex(md5src.getBytes("utf-8")).toUpperCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		/* HCMD5 md5 = new HCMD5();
	    String SignInfo = md5.getMD5ofStr(md5src);//MD5检验结果//MD5加密后的字符串
*/	    map.put("SignInfo", SignInfo);
	    String Remark = "备注";
	    map.put("Remark", Remark);
	    String payType = "";
	    map.put("payType", payType);
	    String url = "https://gwapi.yemadai.com/pay/sslpayment";
	    String sendPost = HttpClientUtil.doPost(url, map);
	    System.out.println(sendPost);
		return sendPost;
		
	}
	
	
	/**   汇付宝========================================================================  */
	
	
	
	/*//汇付宝网银支付方法
	private String heepayWYpay(String bankCode){
		Map<String, Object> map = new HashMap<String, Object>();
		//SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddhhMMss");//格式化时间
		//PropertiesUtil p = new PropertiesUtil("systemNet.properties");
		//String systemNet = p.readProperty("net");
	
		//实例化汇付宝支付订单类
		//HFBGatewayModel model=new HFBGatewayModel();
		map.put("version",1);
		map.put("agent_id", "");
		map.put("agent_bill_id", "");
		map.put("agent_bill_time","" );
		map.put("pay_type", "");
		map.put("pay_amt", "");
		map.put("notify_url","" );
		map.put("return_url", "");
		map.put("user_ip", "");
		map.put("key", "");
		model.setVersion("1");
		model.setPay_type("20");
		model.setPay_code(bankCode);
		model.setAgent_bill_id(spo.getWyPayOrdersCode());
		model.setAgent_bill_time(sdf.format(spo.getWyPayTime()));
		model.setAgent_id(port.getPortuserId());
		model.setNotify_url(systemNet+"/roncoo-pay-web-gateway/WYPayNotify/notify?vender=heepay");
		model.setReturn_url(systemNet+"/roncoo-pay-web-gateway/WYPayReturn/returnUrl?vender=heepay");
		model.setUser_ip("192_168_1_149");
		model.setRemark("hfb");
		model.setGoods_name("testPay");
		model.setGoods_note("hfbPay");
		model.setGoods_num("1");
		model.setPay_amt(String.valueOf(spo.getWyPayMoney()));
		model.setIs_phone("0");
		
		//构建网银或卡类支付跳转地址
		String sign = SignMD5(model, port.getPortuserPwd());
		String submtiurl = null;
		try {
			submtiurl = GateWaySubmitUrl(sign, model, port.getPortwyNet());
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			systemVenderErro.error(e);
			e.printStackTrace();
		}
			
		return submtiurl;
		
	}
	
	//汇付宝微信支付方法
	public static String heepayWXpay(SKPort port , SkWyPayOrder spo){
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddhhMMss");//格式化时间
		PropertiesUtil p = new PropertiesUtil("systemNet.properties");
		String systemNet = p.readProperty("net");
		
		//实例化汇付宝支付订单类
		HFBGatewayModel model=new HFBGatewayModel();
		model.setVersion("1");
		model.setPay_type("30");
		model.setAgent_bill_id(spo.getWyPayOrdersCode());
		model.setAgent_bill_time(sdf.format(spo.getWyPayTime()));
		model.setAgent_id(port.getPortuserId());
		model.setNotify_url(systemNet+"/roncoo-pay-web-gateway/WYPayNotify/notify?vender=heepay");
		model.setReturn_url("http://");
		model.setUser_ip("192_168_1_149");
		model.setRemark("hfb");
		model.setGoods_name("testPay");
		model.setGoods_note("hfbPay");
		model.setGoods_num("1");
		model.setPay_amt(String.valueOf(spo.getWyPayMoney()));
		model.setIs_phone("0");
		
		//构建网银或卡类支付跳转地址
		String sign = SignMD5(model, port.getPortuserPwd());
		String submtiurl = null;
		String QRcode = null;
		try {
			
			submtiurl = GateWaySubmitUrl(sign, model, port.getPortwyNet());
			String page = zhuaziyuan.getURLContent(submtiurl);
			
			Document docu = Jsoup.parse(page);
			
			QRcode = docu.select("input[id=\"hidWeiXin\"]").val();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			systemVenderErro.error("抓取汇付宝微信二维码时，发生异常："+e);
			e.printStackTrace();
			return null;
		}
		
		return QRcode;
	}
	
	
	//汇付宝支付宝支付方法
	public static String heepayALpay(SKPort port , SkWyPayOrder spo){
		
		SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMddhhMMss");//格式化时间
		PropertiesUtil p = new PropertiesUtil("systemNet.properties");
		String systemNet = p.readProperty("net");
		
		//实例化汇付宝支付订单类
		HFBGatewayModel model=new HFBGatewayModel();
		model.setVersion("1");
		model.setPay_type("22");
		model.setAgent_bill_id(spo.getWyPayOrdersCode());
		model.setAgent_bill_time(sdf.format(spo.getWyPayTime()));
		model.setAgent_id(port.getPortuserId());
		model.setNotify_url(systemNet+"/roncoo-pay-web-gateway/WYPayNotify/notify?vender=heepay");
		model.setReturn_url("http://");
		model.setUser_ip("192_168_1_149");
		model.setRemark("hfb");
		model.setGoods_name("testPay");
		model.setGoods_note("hfbPay");
		model.setGoods_num("1");
		model.setPay_amt(String.valueOf(spo.getWyPayMoney()));
		model.setIs_phone("0");
		
		//构建网银或卡类支付跳转地址
		String sign = SignMD5(model, port.getPortuserPwd());
		String submtiurl = null;
		String QRcode = null;
		try {
			
			submtiurl = GateWaySubmitUrl(sign, model, port.getPortwyNet());
			String page = zhuaziyuan.getURLContent(submtiurl);
			
			Document docu = Jsoup.parse(page);
			
			QRcode = docu.select("input[id=\"hiAliPay\"]").val();
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			systemVenderErro.error("抓取汇付宝支付宝二维码时，发生异常："+e);
			e.printStackTrace();
			return null;
		}
		
		return QRcode;
	}
*/
	
	
}
