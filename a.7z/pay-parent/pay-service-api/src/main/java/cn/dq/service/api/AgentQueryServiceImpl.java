package cn.dq.service.api;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.stereotype.Service;

import cn.dq.utils.HttpClientUtil;
import cn.dq.utils.Utils;
/**
 * @author 作者: 杨亚
 * @version 创建时间：2017年3月20日 上午9:21:44
 * 类说明 	代付查询
 */
@Service("agentQueryService")
public class AgentQueryServiceImpl implements AgentQueryService {
	
	
	/**   创新查询单笔代付========================================================================  */
	private String queryCx(){
		Map<String, String> map = new HashMap<String, String>();
		String url = "http://api.shijihuitong.com/cxpayApi/agentPay";//此为测试地址，商户应使用文档中的正式地址
		String key = "c0449b0d72c44389b0a14569f1671e99";//密钥需要商户替换为自己的密钥
		String service = "payForAnotherOneSearch";	    //必填	接口名称
		String merchantNo = "CX0000938";	//必填	商户编号如1001
		String orderNo = "Order20161229152431";	//必填	商户订单号
		String version = "V1.0";	//必填	网关版本
		map.put("service", service);
		map.put("merchantNo", merchantNo);
		map.put("orderNo", orderNo);
		map.put("version", version);
		Map<String, String> sortMap = Utils.sortMapByKey(map);	//按Key进行排序
		for (Map.Entry<String, String> entry : sortMap.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
		String map2string = Utils.map2string(sortMap);
		String sign = "";
		try {
			sign = DigestUtils.md5Hex((map2string+key).getBytes("utf-8"));
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		map.put("sign", sign);
		String result = HttpClientUtil.doPost(url,map);
		System.out.println(result);
		
		//System.out.println(parse.get("dealMsg"));
		return result;
	}
	
	
	/**   汇付宝查询代付========================================================================  */
	private String queryHeep(Map<String, String> map,String key,String url){
		//Map<String, String> map = new HashMap<String, String>();
		url = "https://Pay.heepay.com/API/PayTransit/Query.aspx";//此为测试地址，商户应使用文档中的正式地址
		String version = "2";	    //必填	当前接口版本号 2
		String agent_id = "2065443";	//必填	商户编号如1001
		key = "B323E1DCF26C419598CCF8CB";//密钥需要商户替换为自己的密钥
		String batch_no = "KP20170122020102166725";	//必填	批量付款定单号（要保证唯一）。长度最长50字符	11<批量付款定单号<50
		map.put("agent_id",agent_id );
		map.put("key",key );
		map.put("version", version);
		map.put("batch_no", batch_no);
		Map<String, String> sortMap = Utils.sortMapByKey(map);
		String map2string = Utils.map2string(sortMap);
		String sign = "";
		try {
			sign = DigestUtils.md5Hex((map2string.toLowerCase()).getBytes("utf-8")).toLowerCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		map.remove("key");
		map.put("sign", sign);
		
		String result = HttpClientUtil.doPost(url, map);
		return result;
	}
	
	
	
	/**   墨宝查询代付========================================================================  */
	private String queryMobao(){
		Map<String, String> map = new HashMap<String, String>();
		SimpleDateFormat df = new SimpleDateFormat("yyyyMMdd");//设置日期格式
		String apiName = "SINGLE_SETT_QUERY";	    //必填	接口名字
		String apiVersion = "1.0.0.0";	//必填	接口版本
		String platformID = "1111";	//必填	平台ID
		String merchNo = "210001430017532";	//必填	商户账号
		String tradeDate = df.format(new Date());//交易日期 必输YYYYMMDD年月日
		String orderNo = "orderNo"+tradeDate;	//必填	商户订单号
		String signMsg = "";//交易摘要	 必输，商户对交易数据的签名，签名通过API生成。
		String key = "e5559f05188766d7f99128eedbcf515b";
		String url = "https://trade.mobaopay.com/cgi-bin/netpayment/pay_gate.cgi";
		map.put("apiName", apiName);
		map.put("apiVersion",apiVersion );
		map.put("platformID",platformID );
		map.put("merchNo", merchNo);
		map.put("orderNo", orderNo);
		map.put("tradeDate", tradeDate);
		String paramsStr = String.format(
				"apiName=%s&apiVersion=%s&platformID=%s&merchNo=%s&orderNo=%s&tradeDate=%s",
				map.get("apiName"), map.get("apiVersion"),
				map.get("platformID"), map.get("merchNo"),
				map.get("orderNo"), map.get("tradeDate"));
		System.out.println("paramsStr====="+paramsStr);
		try {
			signMsg = DigestUtils.md5Hex((paramsStr+key).getBytes("utf-8")).toLowerCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	// 签名数据
		//StringBuffer sb = new StringBuffer().append(msgMap.get("paramsStr")).append("&signMsg=").append(signMsg);
		map.put("signMsg",signMsg );
		String doPost = HttpClientUtil.doPost(url, map);
		/*String doPost = HttpUtil.doPost(map.get("url"), "utf-8", sb.toString());
		Map<String, String> resultMap = parsString(doPost);*/
		return doPost;
	}
	
	
	/**   梓微兴查询代付========================================================================  */
	private String queryZwx(){
		Map<String, String> map = new HashMap<String, String>();
		String url = "https://api.zwxpay.com/pay/agentpay/query";//此为测试地址，商户应使用文档中的正式地址
		String key = "http://211.10";
		
		
		String mch_id = "2";	    //必填	商户号 
		String nonce_str = "1023";	//必填	随机字符串，丌长于32位 
		String out_trade_no  = "A810E85881C74460BD6E0397";//否    商户订单号
		String transaction_id  = "beizhu";	//否 	平台代付单号
		String op_user_id = "beizhu";	//否 	操作员帐号
		map.put("mch_id", mch_id);
		map.put("nonce_str", nonce_str);
		map.put("out_trade_no", out_trade_no);
		map.put("transaction_id", transaction_id);
		map.put("op_user_id", op_user_id);
		Map<String, String> sortMap = Utils.sortMapByKey(map);
		String map2string = Utils.map2string(sortMap);
		String sign ="";
		try {
			sign = DigestUtils.md5Hex(((map2string+"&key="+key).toLowerCase()).getBytes("utf-8")).toLowerCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		map.put("sign", sign);
		String result = HttpClientUtil.doPost(url, map);
		System.out.println(result);
		//Map<String, String> resultMap = parsString(result);
		return result;
	}
	/**   梓微兴查询代付========================================================================  */
	/**
	 * 剩余金额
	 * @return
	 */
	private String zwxAlivMoney(){
		Map<String, String> map = new HashMap<String, String>();
		String url = "https://api.zwxpay.com/pay/agentpay/query";//此为测试地址，商户应使用文档中的正式地址
		String key = "http://211.10";
		
		
		String mch_id = "2";	    //必填	商户号 
		String nonce_str = "1023";	//必填	随机字符串，丌长于32位 
		String op_user_id = "beizhu";	//否 	操作员帐号
		map.put("mch_id", mch_id);
		map.put("nonce_str", nonce_str);
		map.put("op_user_id", op_user_id);
		Map<String, String> sortMap = Utils.sortMapByKey(map);
		String map2string = Utils.map2string(sortMap);
		String sign ="";
		try {
			sign = DigestUtils.md5Hex(((map2string+"&key="+key).toLowerCase()).getBytes("utf-8")).toLowerCase();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		map.put("sign", sign);
		String result = HttpClientUtil.doPost(url, map);
		System.out.println(result);
		//Map<String, String> resultMap = parsString(result);
		return result;
	}
	

}
