package cn.dq.service.api;

import org.springframework.stereotype.Service;


/**
 * @author 作者: 杨亚
 * @version 创建时间：2017年3月20日 上午9:21:44
 * 类说明	测试
 */
@Service("apiService")
public class ApiServiceImpl implements ApiService{

	@Override
	public void putMq(String orderNo,String type) {
		// TODO Auto-generated method stub
		
	}

}
